# Lire des exports Google Ads Editor en CSV

Exports produits par l'utilisateur depuis son compte : gros fichiers, colonnes instables, une ligne par entité.

## Avant de parser
- Lire la première ligne et construire les clés depuis elle : le nom de la colonne de statut change selon l'export (`Status` sur la ligne de campagne, `Campaign Status` ailleurs), et `Campaign type` / `Campaign Type` alternent.
- Ouvrir en `utf-8-sig` : BOM `\ufeff` sur la première colonne, sinon la clé `Campaign` n'existe pas et tout `KeyError`.
- Séparateur virgule sur les exports Editor, point-virgule sur les fichiers internes de type `communes.csv` (`departement;ville;cp;population`).

## Pièges de structure
- `Location` n'est renseignée que sur la ligne d'en-tête de campagne : construire une map campagne → localisation, puis reporter sur les lignes de groupes. Lire `Location` ligne par ligne renvoie des vides.
- Les négatifs de campagne arrivent en `Criterion Type = Campaign Negative Keyword` avec un `Match Type`, dupliqués dans chaque campagne. Compter les valeurs distinctes, jamais les lignes.
- Seules les annonces RSA apparaissent : l'absence de ligne d'extension ne prouve pas l'absence d'extension dans le compte, le dire comme "à confirmer dans l'interface".
- Une ligne = une entité (campagne, groupe, mot-clé, annonce). Les lignes vides de `Ad type` portent les campagnes et groupes : ne pas les jeter, elles portent statut, budget et localisation.

## Mesures utiles
- Couverture réelle : nombre de campagnes actives et nombre de localisations distinctes par département.
- Auto-concurrence : compter les couples (localisation, mot-clé) présents dans plusieurs comptes ou marques.
- Pertinence : part des annonces dont un titre contient la ville du groupe, contenu du titre épinglé en position 1.
- Enchères : distribution des `Max CPC` face au coût réel du palier visé (0,20-0,40 € sur une commune, 1-2 € sur un chef-lieu).
