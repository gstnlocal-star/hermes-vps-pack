---
name: windows-remote-host-ops
description: "Diagnostiquer et redémarrer un Windows distant (VPS)."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [windows, rdp, vps, reboot, ops]
    category: productivity
    related_skills: [computer-use]
---

# Administrer un Windows distant (VPS, serveur, VM hors poste)

## When to Use

« Mon VPS est en bug, redémarre-le », « le serveur ne répond plus », accès à
un Windows qui n'est pas cette machine. La demande arrive en une ligne, sans
contexte : à toi de retrouver la cible et le moyen de la piloter.

Un redémarrage est réversible : on agit sans faire valider, mais on vérifie
avant ET après. On demande seulement ce qui tourne sur la machine (robots,
campagnes, services) pour pouvoir le relancer.

## 1. Identifier l'hébergement avant toute chose

La réponse détermine toute la suite : VM locale = redémarrage hyperviseur,
serveur distant = panneau fournisseur.

```bash
# hyperviseurs locaux
ls "/c/Program Files/Oracle/VirtualBox/VBoxManage.exe" \
   "/c/Program Files/VMware/VMware Workstation/vmrun.exe" 2>/dev/null
tasklist | grep -iE "vmware|virtualbox|vboxheadless|vmwp|vmms|qemu"

# cibles RDP déjà connues de la machine (search_files, puis lire la ligne
# "full address:s:<ip>")
find /c/Users/googl -maxdepth 5 -iname "*.rdp" 2>/dev/null
grep -o "full address:s:[^ ]*" "<fichier>.rdp"

# nom du service = fournisseur (vps-xxxxxxxx.vps.ovh.ca => OVH)
nslookup <ip>
```

Les identifiants RDP enregistrés se lisent avec `cmdkey /list` (chercher
`TERMSRV/<ip>`). Le nom d'utilisateur suffit : `mstsc` réutilise le secret
stocké sans jamais le demander.

## 2. Lire l'état réel, sans rien modifier

```bash
ping -n 3 <ip>
# scan de ports courts : 3389 RDP, 22 SSH, 5985/5986 WinRM, 135/445 RPC, 80/443
powershell -NoProfile -Command "\$t=@(3389,22,5985,135,445,80,443); foreach(\$p in \$t){ \$c=New-Object Net.Sockets.TcpClient; \$a=\$c.BeginConnect('<ip>',\$p,\$null,\$null); if(\$a.AsyncWaitHandle.WaitOne(1200) -and \$c.Connected){\"OUVERT \$p\"}; \$c.Close() }"
```

Lecture : 3389 seul ouvert = aucune voie de commande à distance (ni SSH, ni
WinRM, ni RPC), donc tout passera par la console graphique ou le panneau. Si
22 ou 5985 répond, y aller directement (`ssh`, `Enter-PSSession`) plutôt que
par RDP : plus court et scriptable.

## 3. Voie in-band (le bureau distant répond)

```bash
cmd /c start "" mstsc.exe "<chemin>.rdp"   # ou mstsc /v:<ip>
```

- Deux dialogues UIA bloquent chaque nouvelle connexion : « Ouvrir un fichier
  RDP » (case à cocher puis OK) et l'avertissement de sécurité (bouton
  « Connexion »). Les valider par index, sinon la fenêtre reste en attente.
- Une fois connecté, `win+r` puis `shutdown /r /t 0 /f` en
  `delivery_mode="foreground"` (les frappes en background n'atteignent pas
  l'invité), puis `Entrée`.
- Vérification : boucler `ping` ~1 min. La chute des réponses est la seule
  preuve côté client que le reboot a démarré. Sans chute, la commande n'est
  pas passée.
- Écran noir côté bureau : relancer avec un `.rdp` contenant
  `alternate shell:s:cmd.exe` pour court-circuiter un explorateur mort.

## 4. Voie hors-bande (bureau mort, panneau fournisseur)

Un bureau qui ne peint plus (noir en session normale, en shell direct, en
`/admin`, en basse résolution) ne se répare pas en RDP : redémarrage à froid
depuis le panneau (OVH : `manager.ca.ovhcloud.com`, service VPS, bouton
Redémarrer).

Pour s'y rendre sans navigateur neuf, réutiliser la session Chrome de
l'utilisateur : elle tourne avec `--remote-debugging-port=9222` et un onglet
dédié suffit (voir `scripts/cdp_attach.py`, ne pas fermer ses onglets).

Si le panneau exige une connexion, deux choix courts, jamais un roman :

1. « Tu te connectes dans l'onglet OVH déjà ouvert, tu me dis c'est fait, j'enchaîne. »
2. « Tu m'envoies identifiant + mot de passe, je m'occupe de tout. »

Ne pas partir chercher le mot de passe du panneau dans Chrome : il n'y est
pas forcément (voir `references/windows-credentials-dpapi.md`).

## 5. Clore

Dire ce qui est vérifié (telle variante a échoué, tel port est ouvert), ce qui
bloque et pourquoi, ce qui reste à faire après le reboot. Ne jamais annoncer
« c'est redémarré » tant que le ping n'a pas chuté puis repris.

## Pièges

- `taskkill //PID N` échoue dans le bash MSYS de ce poste : `taskkill /PID N /F`.
- Les `.rdp` sont en UTF-16LE : `sed`/`grep` n'y voient rien. Les réécrire avec
  `write_file` (contenu ASCII neuf) plutôt que les éditer sur place.
- Horodater les relevés de ping (`date +%H:%M:%S`) : la preuve devient lisible.
- Une capture de fenêtre `mstsc` noire ne prouve pas que la machine est morte :
  confirmer avec `capture app="screen"` (grab composité) que l'écran physique
  est bien noir.
- Ne pas boucler sur les variantes RDP (résolutions, `/admin`, shadow) plus de
  deux essais : au-delà c'est le panneau. `mstsc /shadow:<id>` sort « Ce nom
  d'ordinateur n'est pas valide » même avec l'IP ou le FQDN : piste secondaire.
- Le blob d'un identifiant `TERMSRV` lu via `CredRead` est vide : le mot de
  passe RDP n'est pas récupérable par cette voie, inutile d'insister.

## Fichiers

- `references/windows-credentials-dpapi.md` — ce qui est extractible (ou non)
  des identifiants Windows/Chrome, et les pièges DPAPI/ctypes.
- `scripts/cdp_attach.py` — piloter l'onglet Chrome de l'utilisateur en CDP
  (navigation, lecture DOM, clic, saisie) sans toucher à ses autres onglets.
