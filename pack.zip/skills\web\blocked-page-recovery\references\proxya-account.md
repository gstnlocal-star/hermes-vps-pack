# Proxya — solde, recharge, regeneration

Utiliser ce fichier des qu'un robot d'Eric tombe en `402` sur ses proxies, ou
qu'il demande de recharger, regenerer ou diagnostiquer son compte Proxya.

Proxya (proxya.co) est le fournisseur residentiel FR d'Eric pour les robots de
saturation. Le compte est en USD et en GB de trafic residentiel : un solde a
zero ne se voit pas dans le code, il se voit au tunnel (`402`).

## Diagnostiquer avant de recharger

Un `ERR_TUNNEL_CONNECTION_FAILED` dans Playwright ne dit rien : il couvre aussi
bien un proxy mort qu'un credit a zero, et un connect TCP (`Test-NetConnection`)
reussit quand le gateway refuse quand meme le tunnel. Seul le statut du
`CONNECT` tranche. `curl -x` n'accepte pas le format du fichier de proxies
`hote:port:user:pass` (« Port number was not a decimal number ») : reecrire en
`http://user:pass@hote:port` et lire la ligne `< HTTP/1.1 402` de la sortie
verbeuse.

1. `requests.get("https://api.ipify.org", proxies=...)` : `402 Payment Required`
   = plus de trafic (quota), `407` = identifiants refuses. Ne pas confondre, les
   correctifs sont opposes.
2. Lire le solde sur `/dashboard/buy?type=residential&tab=generate` : bloc
   `Residential balance … GB left`, et en haut a droite le solde en $. Les deux
   doivent etre a zero pour conclure a une recharge.
3. `/dashboard/transactions` donne le rythme reel (montants deposes, dates,
   `Balance:` apres chaque ligne). C'est la source pour calibrer un montant.
4. Pendant ce temps, arreter le robot : son garde-fou bascule en IP locale et
   brule la meme IP pour rien.

Consommation constatee du robot LSA (500 sessions sticky, volume max) : ~5 GB
par jour, soit 10 GB = ~2 jours. Grille : 10 GB = 20 $, 25 GB = 50 $,
50 GB = 95 $, 100 GB = 180 $. Proposer 25 GB par defaut et laisser Eric
arbitrer ; ne jamais payer sans son accord sur le montant. S'il ne repond pas
vite, creer quand meme la commande et envoyer le lien : rien n'est debite tant
que la crypto n'est pas partie, et une commande en attente n'engage a rien.

## Commander (aucun debit tant que la crypto n'est pas envoyee)

Le depot `/dashboard/deposit` est en crypto seule via Heleket (Carte = « Soon »),
minimum 1 $. Il est plus court d'acheter le trafic directement, ce qui saute le
solde intermediaire :

1. `/dashboard/buy?type=residential`, saisir la quantite dans `input[type=number]`
   puis `dispatch_event("input")` (un `fill` seul ne recalcule pas le total).
2. Decocher « Pay from balance » (sinon 0 $ est pris et le bouton reste inerte).
3. Cliquer « Pay $X » : cree une commande `Pending` valable ~60 min, sans debit.
4. « Pay via Heleket » ouvre un nouvel onglet `pay.heleket.hk`.

## Encaissement

- Choisir la devise et le reseau : USDT + Tron (TRC-20), marque « Best choice »
  par Heleket, frais minimes. ETH/ERC-20 coute cher en gas.
- Le montant affiche inclut les frais (50,05 USDT pour une commande a 50 $) :
  envoyer **le montant exact**, pas le prix de la commande.
- Envoyer tout de suite a Eric : lien de paiement, adresse, montant exact, QR.
  Le coller sur fond blanc avec une marge avant envoi (QR sans zone de silence
  passe mal d'un telephone a l'autre) : screenshot de l'element `<img>`, puis
  `ImageOps.expand(im, border=60, fill="white")` (installer pillow dans le venv
  du projet).
- Si la commande expire, en recreer une : rien n'a ete debite.
- Le credit n'arrive qu'apres 1 confirmation on-chain ; surveiller la commande
  avant d'annoncer que c'est paye.

## Apres paiement — ordre obligatoire

1. Acheter le trafic (ou verifier que la commande a bien credite le solde).
2. Regenerer la liste : onglet `Generate Proxies`, France, Sticky, TTL 10, HTTP,
   port 8888, Count 500, puis export `.txt`.
3. `sort -u` + comptage : 500 lignes doivent donner 500 sessions uniques
   (`…-session-<id>-ttl-10`).
4. Tester la premiere entree sur `api.ipify.org` et verifier le pays avant de
   relancer. Un `Generate` fait sur 0 GB rend 500 proxies morts.
5. Relancer le robot, puis verifier les premieres lignes du CSV : sans `ok`
   dans la minute, le probleme n'est pas resolu.

## Piloter le dashboard sans rouvrir de navigateur

Le dashboard est dans le Chrome d'Eric, deja connecte. S'y attacher en CDP
(`connect_over_cdp("http://127.0.0.1:9222")`) et reutiliser l'onglet
`proxya.co` : on garde les cookies et on n'empile pas les onglets qu'il suit.

Pieges de selecteurs rencontres sur ce dashboard :

- `get_by_text("…", exact=True)` leve une violation de mode strict (libelle
  duplique label + placeholder) : viser `.last` ou passer par `bounding_box()`.
- Les comboboxes Heleket ne s'ouvrent pas au clic sur le texte : recuperer la
  `bounding_box` du champ puis `mouse.click(x+w/2, y+h/2)`.
- Verifier chaque etape par une capture (`page.screenshot`) et une lecture de
  texte, pas par l'espoir que le clic a porte.
