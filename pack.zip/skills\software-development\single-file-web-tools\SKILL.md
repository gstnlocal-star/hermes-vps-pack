---
name: single-file-web-tools
description: "Use when building an offline single-file browser tool."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [web, html, client-side, offline, generator, javascript]
    related_skills: [dogfood, claude-design]
---

# Single-File Client-Side Tools

## When to Use

Use when the user asks for a tool he can keep and run himself: generator,
decoder, calculator, checker, converter — anything specified as "no backend, no
external dependency, everything client-side". Also load it before editing an
already delivered tool of that shape.

For utilities the user wants to own and run locally: one self-contained HTML
file, no backend, no CDN, no build step, works from `file://` on a double-click.
UI in French, dark theme, dense and factual — this is a work tool, not a landing
page.

## Procedure

1. **Ground the spec before writing code.** Find an official document (regulator,
   standard, vendor spec) AND a second, independent implementation of the same
   algorithm. Two sources that disagree mean the spec is not settled — say so
   instead of picking one. When the user's own description of the algorithm is
   truncated (a message that stops at `Pseudo-code :`), implement the
   authoritative version and state which source you used.
2. **Write the naive, readable implementation first**, exactly as the reference
   states it. That function stays in the file: it is the oracle the fast path is
   tested against.
3. **Optimise only if the search space demands it**, then prove equivalence (see
   pitfall 2).
4. **Build the UI** with explicit validation, real outputs (copy button, TXT and
   CSV export of the full result set, result cap, stop button, progress count),
   and the domain caveats written into the page itself.
5. **Verify with real execution** — algorithm, UI, exports — then deliver the
   path. See `references/browser-verification.md` for the browser workflow and
   its traps.

## Non-negotiables

- **Zero network.** No `<script src>`, no font CDN, no inline fetch. Confirm with
  `grep -oE '(src|href)="https?://[^"]+"' file.html` returning nothing.
- **Big data stays inline.** Fetching a sibling JSON breaks on `file://`; embed
  the dataset in the file (10 KB of table is nothing) and template the file from
  a source copy with a placeholder, then rebuild after every patch.
- **Say what the tool cannot do.** A generator whose output cannot be validated
  by the tool itself (a checksummed identifier must still exist in a third
  party's database, for instance) is half an answer: state the oracle problem in
  the page and in the reply, and offer the automation step.
- Compute only what cannot be looked up. Precompute fixed parts, keep the inner
  loop to integer arithmetic, never `BigInt` inside a million-iteration loop.

## Pitfalls

1. **A cross-check built on random data of the wrong shape proves nothing.**
   Generate the exact string the app builds — fixed prefix + variable part +
   number — or the reference and the optimised path never line up and you get
   100 % mismatch on correct code. Verify, then walk one case by hand.
2. **Optimised arithmetic must be derived, not guessed.** When the naive loop is
   a linear recurrence (`b = (2*b + p) % 37`), the fast path is a per-position
   weight table; a slot forgotten in the table (slot 0 of six) yields plausible
   strings with wrong keys. Compare every slot's contribution against the naive
   function on 5 000 random inputs before touching the UI.
3. **Never break the page the user has open.** He watches his own Chrome and
   says so; `new_tab`/`goto_url` elsewhere steals his view. Edit the file, then
   `js("location.reload()")` on the existing tab and keep that tab for the whole
   session.
4. **`page_info()` returns a dict** — wrap it in `str()` before slicing.
   **`capture_screenshot()` reuses one path** — copy the file if you need two
   shots. **`Target.activateTarget` needs the full target id** — print full ids,
   not the first 8 hex chars.
5. **Only the first download from a page is auto-allowed.** A second export
   click in the same page silently writes nothing; test each export on a fresh
   page, or verify one at a time by checking the download folder.
6. **`js()` cannot see a `chrome-error://chromewebdata` interstitial** (cert
   warning): the click-through buttons are invisible to it. Fetch with
   `curl -sk` instead, or pick another host.
7. **Counted yields, not timed ones.** `await new Promise(r=>setTimeout(r,0))`
   resumed in a hidden tab is throttled to ~1 s, so a
   `performance.now() > lastPaint + 60` guard placed after the await fires again
   immediately and the loop collapses to one item per second. Yield every N items
   (20 000), and reset the paint clock *after* the await, not before.
8. **Coherent counters.** Labelling a scan "testés / retenus" when every item is
   kept reads as a bug. Say "balayés / générés", and drive the progress bar from
   a computed percentage that also ends at 100 %.
9. **A disabled control must look disabled, an active one must not.**
   `opacity` alone makes a real button look dead: give the disabled state its own
   neutral colours (`:disabled` rule) and keep the destructive colour for the
   enabled state.
10. **`th` inside an `overflow:auto` wrapper needs an explicit height** —
    sticky headers clip their own text otherwise.

## Legibility pass

Screenshot, then `vision_analyze` the shot with a question about alignment,
contrast and wrapping. It reliably catches what code review does not: labels
breaking onto two lines, a segmented control stretched taller than its
neighbouring inputs, a 3:1 button, a clipped header row. Fix, reload, re-shoot.

## Support files

- `references/browser-verification.md` — browser test loop, instrumentation,
  export checks, what to assert before saying "done".
- `references/french-rio-numbering.md` — RIO structure, key algorithm, ARCEP
  prefix and numbering sources, operator lookup.
- `scripts/gen_rio_candidates.py` — stdlib generator + naive verifier for RIO
  candidate lists.
