# Cas Nicolas Services (nicolas-service.com) — audit du 17/11/2026

Modèle d'arbitrage de leads, pas un artisan.

- Annonceur : Ayari Erwan, 26 ans, identité validée ; ~300 annonces texte, 1re diffusion 19/12/2025, toujours actives.
- Portefeuille : même numéro 07 56 99 81 90 sur serrurier-martin.fr et plombier-martin.fr ; 4 comptes annonceurs par domaine.
- Site Next.js statique sur Cloudflare, TTFB 0,5 s, domaine enregistré le 12/06/2026 pour 1 an.
- 360 pages = 180 villes x 2 métiers, 17 deps (22, 29, 30, 31, 33, 34, 35, 44, 54, 55, 56, 57, 59, 62, 67, 68, 85), préfecture + communes de 1re couronne, Paris et 27/76 évités.
- LP : 760 mots, 8 occurrences de la ville, 3 fois le même CTA téléphone, barre collante, zéro formulaire, zéro analytics, zéro tag de conversion, mentions légales vides, aucun GBP, note 4,8/6570 avis en dur dans le JSON-LD.
- Impressions par création : 0 à 2 000 sur 8 mois, soit un budget très étalé. Estimation 200-600 €/mois sur 17 deps.
- Failles : aucune preuve vérifiable (avis, adresse, mentions), zéro mesure, pages interchangeables, pas de fiche locale, cassé sur les requêtes de tête.

## Lecture pour l'utilisateur
Sur ses 17 deps, seules 5 étaient sans aucune campagne chez l'utilisateur qui le suit. Les 12 autres étaient déjà couvertes ou partiellement couvertes. Le trou réel n'est donc pas "les deps du concurrent" mais le croisement avec les exports Ads, département par département.
