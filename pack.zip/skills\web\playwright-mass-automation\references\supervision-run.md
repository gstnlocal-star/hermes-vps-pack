# Superviser, mesurer et arrêter un run en cours

Commandes Windows vérifiées. Toutes les mesures se lisent dans les artefacts
(CSV, compteurs d'état), **jamais** dans le titre de fenêtre ni sur la parole du
bot : l'interface d'un robot figé affiche encore « en marche ».

## Lister ce qui tourne réellement

```bash
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { \$_.CommandLine -match 'mon_robot.py|demarrer.py' } | Select-Object ProcessId,ParentProcessId,Name,@{n='CL';e={\$_.CommandLine.Substring(0,[Math]::Min(100,\$_.CommandLine.Length))}} | Format-Table -AutoSize | Out-String -Width 200"
```

Un processus par robot est normal ; deux `python(w).exe` portant le même script
avec des PID différents = doublons à supprimer. Le `ParentProcessId` dit si le
processus est tenu par une boucle `.bat` (le parent est un `cmd.exe`).

## Mesurer le débit réel

```bash
cd "<dossier du run>" && wc -l run_*.csv && tail -3 run_*.csv | cut -d';' -f1-6 && date
```

L'écart entre le dernier horodatage du CSV et `date` est le temps de silence :
plus de 60 s sans ligne neuve = run mort, quel que soit l'affichage.

## Arrêt propre (ordre imposé)

Script paramétrable qui applique tout l'ordre : `scripts/stop_robots.ps1`.
À la main, si le script n'est pas chargé :

```bash
# 1. tuer les cmd qui portent les boucles .bat (sinon elles relancent)
taskkill //F //T //PID <pid_du_cmd>
# 2. tuer les enfants survivants : taskkill //F //T //PID <pid>
# 3. relister, et répéter jusqu'à ce que la liste reste vide 60-90 s
```

Règles qui font la différence entre « arrêté » et « en pause » :

- **Ne jamais tuer les `python.exe` de Hermes** : filtrer
  `CommandLine -notlike '*hermes*'` (gateway, kernel runner, browser harness).
  Sans ce filtre, on tue ses propres mains en même temps.
- **Balayer aussi les scripts de diagnostic** (`test*.py`, `mini*.py`,
  `dump_*`, `-c "…"` inline, `node.exe` du driver Playwright) : ils tiennent des
  navigateurs et des sessions proxies. Un run `dry=True` n'envoie aucun message,
  mais reste un run à couper sur un « stop tout ».
- **Prouver la stabilité sur 60-90 s** : un relevé vide juste après les kills ne
  prouve rien, une boucle relancée recrée des processus en ~20 s. Répéter les
  passes jusqu'à ce que la liste reste vide, en comptant les kills.
- **Tenir dans le temps** : si les robots reviennent malgré les passes, lancer
  une garde en tâche de fond (`while elapsed < N { kill; sleep 3 }`), annoncer
  sa durée et son heure d'expiration. Ne pas présenter un arrêt comme définitif
  tant qu'une autre session peut relancer.
- **Conserver les preuves avant de rendre compte** : `etat.json` et les CSV
  restent sur disque et servent de reprise ; les citer (nombre de clients déjà
  contactés) rassure et permet de repartir sans repasser sur les mêmes cibles.

## Reconstituer ce qui s'est passé après coup

- Historique de session Hermes : base `~/AppData/Local/hermes/state.db`, table
  `messages` (colonnes `session_id`, `role`, `content`, `timestamp`), triée par
  `timestamp` — donne l'heure exacte des lancements et des « stop ».
- Journaux des robots : dossier `debug/` du projet, fichiers `run_*.log`.

## Pièges

- Dans `terminal` sous bash, `$var` PowerShell est mangé par le shell : échapper
  en `\$_` / `\$o`, passer par des simples quotes (`-Command '...'`), ou mieux
  écrire un `.ps1` dans le scratch et lancer
  `powershell -NoProfile -ExecutionPolicy Bypass -File "C:/chemin/stop.ps1"`
  (chemin en slashes, la conversion MSYS des arguments est coupée).
- `cmd //c "taskkill /PID x /T /F"` depuis bash rend seulement la bannière de
  `cmd` et avale la sortie : appeler `taskkill //PID x //T //F` directement.
- Tuer les enfants avant le `.bat` recrée des doublons en quelques secondes.
- `taskkill` sur un PID déjà mort renvoie « introuvable » : ce n'est pas un
  échec, c'est un run déjà arrêté — vérifier par la liste, pas par le code retour.
